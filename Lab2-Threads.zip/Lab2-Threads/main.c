#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>


typedef struct
{
    int x;
    int y;

} elementMultSizes;

typedef struct
{
    int x;
    int y;

} rowMultSizes;

int MatA[100][100];
int MatB[100][100];
int result[100][100];

void calculateCell(void* arguments)
{
    elementMultSizes *mult = arguments;
    int k;
    int i = mult->x;
    int j = mult->y;

    for( k=0; k<100; k++ )
        result[i][j] = result[i][j] + (MatA[i][k] * MatB[k][j]);

    pthread_exit(0);
}

void elementMult(int rows1, int rows2, int columns1, int columns2)
{
    elementMultSizes mult;
    pthread_t t1;

    for( mult.x=0; mult.x<rows1; mult.x++ )
        for( mult.y=0; mult.y<columns2; mult.y++ )
        {
            pthread_create(&t1, NULL, calculateCell, (void *) &mult);
            pthread_join(t1, NULL);
        }
}

void calculateRow(int i)
{
    int j,k;

    for( j=0; j<100; j++ )
        for( k=0; k<100; k++ )
            result[i][j] = result[i][j] + (MatA[i][k] * MatB[k][j]);


    pthread_exit(0);
}

void rowMult(int rows1, int rows2, int columns1, int columns2)
{
    rowMultSizes mult;
    pthread_t t2;

    for( mult.x=0; mult.x<rows1; mult.x++ )
    {
        pthread_create(&t2, NULL, calculateRow, mult.x);
        pthread_join(t2, NULL);
    }
    int a,b;
    for(a=0; a<rows1; a++)
        for(b=0; b<columns2; b++)
            printf("%d\n", result[a][b]);
}

int main()
{
    FILE * file = fopen("input.txt", "r");
    int i,j,k,l;
    int rows1, rows2, columns1, columns2;
    clock_t s1, e1, s2, e2;
    double time1, time2;

    if (  file == NULL )
        perror("Error! Couldn't open file\n");
   else
    {
        fscanf(file, "%d", &rows1);
        fscanf(file, "%d", &columns1);

        for( i=0; i<rows1; i++ )
            for( j=0; j<columns1; j++ )
                fscanf(file, "%d%*c", &MatA[i][j]);

        fscanf(file, "%d", &rows2);
        fscanf(file, "%d", &columns2);

        for( k=0; k<rows2; k++ )
            for( l=0; l<columns2; l++ )
                fscanf(file, "%d%*c", &MatB[k][l]);
    }

        printf("Element-by-element multiplication: \n");
        s1 = clock();
        elementMult(rows1,rows2,columns1,columns2);
        e1 = clock();
        time1 = ((double)(e1 - s1)) / CLOCKS_PER_SEC;
        printf("%f", time1);

        printf("Row-by-row multiplication: \n");
        s2 = clock();
        rowMult(rows1,rows2,columns1,columns2);
        e2 = clock();
        time2 = ((double)(e2 - s2)) / CLOCKS_PER_SEC;
        printf("%f", time2);



    FILE * output = fopen("output.txt", "wb");                //Binary writing mode
    fwrite(result, sizeof(int), sizeof(result), output);
    fprintf(output, "END1", time1);
    fprintf(output, "END1", time2);
    fclose(output);

    return 0;
}






/* C program for Merge Sort */
#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>

int n;
int a[n];

struct details
{
    int low;
    int high;
};

//void readFile()
//{
//    FILE * file = fopen("input.txt", "r");
//
//    if (  file == NULL )            //Tests if file doesn't exist
//        perror("Error! Couldn't open file\n");
//    else
//    {
//        fscanf(file, "%d", &n);
//
//        for(int i=0; i<n; i++ )
//            fscanf(file, "%d%*c", &a[i]);
//
//                   fclose(file);
//        }
//}

// Merges two subarrays of arr[].
// First subarray is arr[l..m]
// Second subarray is arr[m+1..r]
void merge(int a[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    /* create temp arrays */
    int L[n1], R[n2];

    /* Copy data to temp arrays L[] and R[] */
    for (i = 0; i < n1; i++)
        L[i] = a[l + i];
    for (j = 0; j < n2; j++)
        R[j] = a[m + 1+ j];

    /* Merge the temp arrays back into arr[l..r]*/
    i = 0; // Initial index of first subarray
    j = 0; // Initial index of second subarray
    k = l; // Initial index of merged subarray
    while (i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            a[k] = L[i];
            i++;
        }
        else
        {
            a[k] = R[j];
            j++;
        }
        k++;
    }

    /* Copy the remaining elements of L[], if there
    are any */
    while (i < n1)
    {
        a[k] = L[i];
        i++;
        k++;
    }

    /* Copy the remaining elements of R[], if there
    are any */
    while (j < n2)
    {
        a[k] = R[j];
        j++;
        k++;
    }
}

/* l is for left index and r is right index of the
sub-array of arr to be sorted */
void* mergeSort(void* args)
{
    struct details *d = (struct details*) args;
    struct details d1, d2;

    pthread_t tLow, tHigh;

    if (d->low < d->high)
    {
        // Same as (l+r)/2, but avoids overflow for
        // large l and h
        int m = d->low+(d->high-d->low)/2;
        d1.low = d->low;
        d1.high = m;

        // Sort first and second halves
        pthread_create(&tLow, NULL, mergeSort, (void*)&d1);

        d2.low = m+1;
        d2.high = d->high;

        pthread_create(&tHigh, NULL, mergeSort, (void*)&d2);

        pthread_join(tLow, NULL);
        pthread_join(tHigh, NULL);

        merge(a, d->low, m, d->high);
    }
}

/* UTILITY FUNCTIONS */
/* Function to print an array */
void printArray(int A[], int size)
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", A[i]);
    printf("\n");
}

/* Driver program to test above functions */
int main()
{
    readFile();

    printf("Given array is \n");
    printArray(a, n);

    pthread_t t;
    clock_t t1, t2;

    struct details d;
    d.low = 0;
    d.high = n-1;

    t1 = clock();

    pthread_create(&t, NULL, mergeSort, (void*)&d);
    pthread_join(t, NULL);

    t = clock();

    printf("\nSorted array is \n");
    printArray(a, n);

    printf("\nTime taken: %f\n", (t2 - t1)/(double)CLOCKS_PER_SEC);
    return 0;
}
